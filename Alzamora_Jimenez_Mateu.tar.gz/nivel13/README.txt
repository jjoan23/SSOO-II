Miembros del grupo:
- Joan Jiménez Rigo
- Climent Alzamora Alcover 
- Marc Mateu Deyá 

Hemos usado las constantes FALLO (-1) y EXITO (0) para realizar todos los returns. 

MEJORAS IMPLEMENTADAS: 

1. mi_ls -l
Hemos implementado la mejora correspondiente al nivel 8 que hace referencia mi_ls -l que significa que hemos 
aplicado la lectua de directorios extendido. 